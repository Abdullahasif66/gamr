MOBILE PARTS SHOP POS — ANDROID PROJECT

Yeh Android Studio project hai. Is workspace mein Android SDK/Gradle build tools installed nahin thay,
is liye yahan se verified APK binary compile nahin ki ja saki.

APK banane ka free tareeqa:
1. Computer par Android Studio install karein: https://developer.android.com/studio
2. ZIP extract karein.
3. Android Studio > Open > extracted MobilePartsShop-Android-Project folder select karein.
4. Gradle sync complete hone dein (internet required for first build).
5. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
6. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.
7. APK ko Android phone par bhejein aur install karein. Phone poochay to is file manager/browser ko
   "Install unknown apps" permission dein, sirf tab jab aap file par trust karte hon.

IMPORTANT:
- App ka data is phone ki app storage/browser storage mein local rehta hai.
- Windows POS ke records automatically import/sync nahin honge. Agar aapke Windows app ka data chahiye
  to uska Backup JSON export karke mobile app mein Restore option se import karna hoga, agar format compatible ho.
- Pehli dafa app install karne se pehle apne Windows POS ka Backup zaroor lein.
- APK ko sign/publish karne se pehle real device par billing, backup/restore aur printing test karein.
