'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const KEYS = { products: 'mps_secure_products_v1', sales: 'mps_secure_sales_v1', customers: 'mps_secure_customers_v1', pin: 'mps_pin_v1', backup: 'mps_last_backup_v1' };
  const DATA_KEYS = ['products', 'sales', 'customers'];
  const CATEGORIES = ['LCD','Battery','Charging Jack','Flex Cable','Speaker / Mic','Camera','Cover / Glass','Charger / Cable','Other'];
  let products = [], sales = [], customers = [];
  let cart = [];
  let activeCustomer = '';

  /* ---------- helpers ---------- */
  function safeLoad(key) {
    try {
      const parsed = JSON.parse(localStorage.getItem(key) || 'null');
      return Array.isArray(parsed) ? parsed : [];
    } catch (_) { return []; }
  }
  function load() {
    products = safeLoad(KEYS.products).filter(p => p && typeof p === 'object');
    sales = safeLoad(KEYS.sales).filter(s => s && typeof s === 'object' && Array.isArray(s.items));
    customers = safeLoad(KEYS.customers).filter(c => c && typeof c === 'object').map(c => ({
      id: String(c.id || makeId()), name: String(c.name || ''), phone: String(c.phone || ''),
      discount: Number(c.discount) || 0, items: Array.isArray(c.items) ? c.items : []
    }));
  }
  function persist() {
    const old = {};
    try {
      DATA_KEYS.forEach(k => { old[k] = localStorage.getItem(KEYS[k]); });
      DATA_KEYS.forEach(k => localStorage.setItem(KEYS[k], JSON.stringify({products, sales, customers}[k])));
    } catch (_) {
      try { DATA_KEYS.forEach(k => old[k] === null || old[k] === undefined ? localStorage.removeItem(KEYS[k]) : localStorage.setItem(KEYS[k], old[k])); } catch (_) {}
      load(); cart = [];
      renderAll();
      alert('Could not save data. This change was NOT saved. Export a backup and check disk/browser storage.');
      return false;
    }
    renderAll();
    say('Saved');
    return true;
  }
  let sayTimer = 0;
  function say(msg) {
    const el = $('toast'); if (!el) return;
    el.textContent = msg; el.classList.add('show'); clearTimeout(sayTimer);
    sayTimer = setTimeout(() => el.classList.remove('show'), 2800);
  }
  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function makeId() {
    return (crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  }
  const r2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
  function money(value) { return 'Rs. ' + Number(value || 0).toLocaleString('en-PK', {maximumFractionDigits: 2}); }
  function validText(value, max) { return String(value || '').trim().slice(0, max); }
  function validNumber(value, min, max, integer = false) {
    if (value === '' || value === null || value === undefined) return null;
    const n = Number(value);
    if (!Number.isFinite(n) || n < min || n > max || (integer && !Number.isInteger(n))) return null;
    return n;
  }
  function nextReceipt() {
    let max = 0;
    sales.forEach(s => { const m = /^R-(\d+)$/.exec(s.receipt || ''); if (m) max = Math.max(max, Number(m[1])); });
    return 'R-' + String(max + 1).padStart(4, '0');
  }
  function nowStamp() { const d = new Date(); return {timestamp: d.getTime(), date: d.toLocaleString()}; }
  function showPage(name) {
    document.querySelectorAll('.page').forEach(p => p.classList.toggle('hidden', p.id !== `page-${name}`));
    document.querySelectorAll('.nav').forEach(b => b.classList.toggle('active', b.dataset.page === name));
    if (name === 'products') renderProducts();
    if (name === 'billing') { renderBillCustomers(); renderBillProducts(); renderCart(); }
    if (name === 'customers') renderCustomers();
    if (name === 'history') renderHistory();
  }
  function printHTML(html) {
    $('printRoot').innerHTML = html;
    if (window.AndroidPOS && typeof window.AndroidPOS.printPage === 'function') {
      window.AndroidPOS.printPage();
    } else {
      window.print();
    }
  }

  /* ---------- events ---------- */
  document.querySelectorAll('.nav').forEach(btn => btn.addEventListener('click', () => showPage(btn.dataset.page)));
  $('quickAddBtn').addEventListener('click', () => openProduct());
  $('newBillBtn').addEventListener('click', () => showPage('billing'));
  $('addProductBtn').addEventListener('click', () => openProduct());
  $('cancelProductBtn').addEventListener('click', () => $('productDialog').close());
  $('productSearch').addEventListener('input', renderProducts);
  $('clearProductSearch').addEventListener('click', () => { $('productSearch').value = ''; renderProducts(); });
  $('billSearch').addEventListener('input', renderBillProducts);
  $('discount').addEventListener('input', renderCart);
  $('billCustomer').addEventListener('change', () => { renderCart(); });
  $('printSaveBtn').addEventListener('click', () => completeSale(true));
  $('saveSaleBtn').addEventListener('click', () => completeSale(false));
  $('addToTabBtn').addEventListener('click', addToTab);
  $('clearCartBtn').addEventListener('click', clearCart);
  $('clearCartBtn2').addEventListener('click', clearCart);
  $('refreshHistory').addEventListener('click', renderHistory);
  $('exportBtn').addEventListener('click', exportData);
  $('importBtn').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', importData);
  $('productForm').addEventListener('submit', saveProduct);
  $('addCustomerBtn').addEventListener('click', () => { $('customerForm').reset(); $('customerError').textContent = ''; $('customerDialog').showModal(); $('cName').focus(); });
  $('cancelCustomerBtn').addEventListener('click', () => $('customerDialog').close());
  $('customerForm').addEventListener('submit', saveCustomer);
  $('customerSearch').addEventListener('input', renderCustomers);
  window.addEventListener('storage', e => {
    if (Object.values(KEYS).includes(e.key)) { load(); renderAll(); }
  });

  /* ---------- products ---------- */
  function openProduct(productId = '') {
    const p = products.find(x => x.id === productId);
    $('productForm').reset();
    $('editId').value = p?.id || '';
    $('dialogTitle').textContent = p ? 'Edit product' : 'Add product';
    $('pName').value = p?.name || '';
    $('pModel').value = p?.model || '';
    $('pCategory').value = CATEGORIES.includes(p?.category) ? p.category : 'LCD';
    $('pSku').value = p?.sku || '';
    $('pCost').value = p?.cost ?? 0;
    $('pPrice').value = p?.price ?? 0;
    $('pStock').value = p?.stock ?? 0;
    $('pLow').value = p?.low ?? 3;
    $('formError').textContent = '';
    $('productDialog').showModal();
  }
  function saveProduct(event) {
    event.preventDefault();
    const name = validText($('pName').value, 100);
    const model = validText($('pModel').value, 100);
    const sku = validText($('pSku').value, 50);
    const cost = validNumber($('pCost').value, 0, 100000000);
    const price = validNumber($('pPrice').value, 0, 100000000);
    const stock = validNumber($('pStock').value, 0, 10000000, true);
    const low = validNumber($('pLow').value === '' ? 0 : $('pLow').value, 0, 10000000, true);
    if (!name || cost === null || price === null || stock === null || low === null) {
      $('formError').textContent = 'Please enter a name and valid non-negative prices and whole-number quantities.';
      return;
    }
    const old = products.find(x => x.id === $('editId').value);
    if (sku && products.some(x => (x.sku || '').toLowerCase() === sku.toLowerCase() && x.id !== old?.id)) {
      $('formError').textContent = 'This SKU already exists. Please use a unique code.';
      return;
    }
    const p = { id: old?.id || makeId(), name, model, sku, category: $('pCategory').value, cost, price, stock, low };
    if (old) products = products.map(x => x.id === old.id ? p : x); else products.push(p);
    $('productDialog').close();
    persist();
  }
  function renderProducts() {
    const query = ($('productSearch').value || '').toLowerCase();
    const rows = products.filter(p => [p.name, p.model, p.category, p.sku].join(' ').toLowerCase().includes(query));
    $('productRows').innerHTML = rows.map(p => `<tr data-id="${esc(p.id)}">
      <td class="cell" data-f="name"><b>${esc(p.name)}</b>${p.sku ? '<small>' + esc(p.sku) + '</small>' : ''}</td>
      <td class="cell" data-f="model">${esc(p.model)}</td>
      <td><span class="tag">${esc(p.category)}</span></td>
      <td class="cell num" data-f="cost">${money(p.cost)}</td>
      <td class="cell num" data-f="price">${money(p.price)}</td>
      <td class="num dim">${money(r2(p.price - p.cost))}</td>
      <td class="cell num ${p.stock <= p.low ? 'stock-low' : 'stock-ok'}" data-f="stock">${p.stock}</td>
      <td class="act"><button class="mini secondary" data-action="edit" data-id="${esc(p.id)}">Edit</button><button class="mini danger" data-action="delete" data-id="${esc(p.id)}">Delete</button></td>
    </tr>`).join('') || `<tr><td colspan="8" class="empty">${products.length ? 'No product matches your search.' : 'No products yet. Press "Add product" to enter your first part.'}</td></tr>`;
    applySelection();
  }
  /* ---- Excel-style cell selection and editing ---- */
  const EDIT_COLS = ['name', 'model', 'cost', 'price', 'stock'];
  let selCell = null, editing = null;
  function cellInfo(td) { return {id: td.parentElement.dataset.id, f: td.dataset.f}; }
  function findCell(sel) {
    const tr = [...$('productRows').rows].find(r => r.dataset.id === sel.id);
    return tr && [...tr.cells].find(c => c.dataset.f === sel.f);
  }
  function applySelection() {
    $('productRows').querySelectorAll('td.selected').forEach(t => t.classList.remove('selected'));
    if (!selCell) return;
    const td = findCell(selCell);
    if (td) { td.classList.add('selected'); td.scrollIntoView({block: 'nearest', inline: 'nearest'}); }
  }
  function moveSel(dx, dy) {
    const rows = [...$('productRows').rows].filter(r => r.dataset.id);
    if (!rows.length) return;
    if (!selCell) { selCell = {id: rows[0].dataset.id, f: EDIT_COLS[0]}; applySelection(); return; }
    let ri = Math.max(0, rows.findIndex(r => r.dataset.id === selCell.id)), ci = EDIT_COLS.indexOf(selCell.f);
    ri = Math.min(rows.length - 1, Math.max(0, ri + dy)); ci = Math.min(EDIT_COLS.length - 1, Math.max(0, ci + dx));
    selCell = {id: rows[ri].dataset.id, f: EDIT_COLS[ci]}; applySelection();
  }
  function startEdit(td, initial) {
    if (editing || !td) return;
    const {id, f} = cellInfo(td), p = products.find(x => x.id === id);
    if (!p) return;
    const num = ['cost', 'price', 'stock'].includes(f);
    const input = document.createElement('input');
    input.className = 'cell-input'; input.type = num ? 'number' : 'text'; input.maxLength = 100;
    if (num) { input.min = '0'; input.step = f === 'stock' ? '1' : '.01'; }
    input.value = initial !== undefined ? initial : p[f];
    td.textContent = ''; td.appendChild(input); input.focus(); if (initial === undefined) input.select();
    editing = {id, f, input};
    input.addEventListener('keydown', ev => {
      if (ev.key === 'Enter') { ev.preventDefault(); commitEdit(0, 1); }
      else if (ev.key === 'Escape') { ev.preventDefault(); editing = null; renderProducts(); $('productGrid').focus(); }
      else if (ev.key === 'Tab') { ev.preventDefault(); commitEdit(ev.shiftKey ? -1 : 1, 0); }
    });
    input.addEventListener('blur', () => { if (editing && editing.input === input) commitEdit(0, 0, true); });
  }
  function commitEdit(dx, dy, fromBlur) {
    const e = editing; if (!e) return; editing = null;
    const raw = e.input.value, p = products.find(x => x.id === e.id);
    let val;
    if (e.f === 'name') val = validText(raw, 100) || null;
    else if (e.f === 'model') val = validText(raw, 100);
    else if (e.f === 'stock') val = validNumber(raw, 0, 10000000, true);
    else val = validNumber(raw, 0, 100000000);
    if (!p || val === null) { say(e.f === 'name' ? 'Item name cannot be empty. Change not saved.' : 'Enter a valid number (0 or more; stock must be whole). Change not saved.'); renderProducts(); if (!fromBlur) $('productGrid').focus(); return; }
    if (p[e.f] !== val) { products = products.map(x => x.id === e.id ? {...x, [e.f]: val} : x); if (!persist()) return; } else renderProducts();
    if (dx || dy) moveSel(dx, dy);
    if (!fromBlur) $('productGrid').focus();
  }
  $('productRows').addEventListener('click', e => {
    const td = e.target.closest('td.cell'); if (!td || editing) return;
    selCell = cellInfo(td); applySelection(); $('productGrid').focus({preventScroll: true});
  });
  $('productRows').addEventListener('dblclick', e => { const td = e.target.closest('td.cell'); if (td) { selCell = cellInfo(td); startEdit(td); } });
  $('productGrid').addEventListener('keydown', e => {
    if (editing || e.target !== $('productGrid')) return;
    const k = e.key;
    if (k === 'ArrowDown') { e.preventDefault(); moveSel(0, 1); }
    else if (k === 'ArrowUp') { e.preventDefault(); moveSel(0, -1); }
    else if (k === 'ArrowLeft') { e.preventDefault(); moveSel(-1, 0); }
    else if (k === 'ArrowRight' || k === 'Tab' && !e.shiftKey && selCell) { e.preventDefault(); moveSel(1, 0); }
    else if ((k === 'Enter' || k === 'F2') && selCell) { e.preventDefault(); startEdit(findCell(selCell)); }
    else if (k.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey && selCell) { e.preventDefault(); startEdit(findCell(selCell), k); }
  });
  $('productRows').addEventListener('click', event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const p = products.find(x => x.id === button.dataset.id);
    if (!p) return;
    if (button.dataset.action === 'edit') openProduct(p.id);
    if (button.dataset.action === 'delete' && confirm(`Delete ${p.name}? (Past sales and customer tabs keep their records.)`)) {
      products = products.filter(x => x.id !== p.id); cart = cart.filter(x => x.id !== p.id); persist();
    }
  });

  /* ---------- billing ---------- */
  function renderBillProducts() {
    const query = ($('billSearch').value || '').toLowerCase();
    const list = products.filter(p => [p.name, p.model, p.category, p.sku].join(' ').toLowerCase().includes(query) && p.stock > 0).slice(0, 150);
    $('billProductRows').innerHTML = list.map(p => `<button class="pick" data-action="add" data-id="${esc(p.id)}">
      <span class="pn"><b>${esc(p.name)}</b><small>${esc(p.model)}</small></span>
      <span class="pp">${money(p.price)}</span>
      <span class="ps ${p.stock <= p.low ? 'low' : ''}">${p.stock} left</span><span class="pa" aria-hidden="true">+</span></button>`
    ).join('') || `<p class="empty">${products.length ? 'No in-stock item matches your search.' : 'No products yet. Add parts in Products first.'}</p>`;
  }
  $('billProductRows').addEventListener('click', event => {
    const button = event.target.closest('button[data-action="add"]');
    if (button) addToCart(button.dataset.id);
  });
  function renderBillCustomers(preselect) {
    const sel = $('billCustomer');
    const current = preselect !== undefined ? preselect : sel.value;
    sel.innerHTML = '<option value="">Walk-in customer (pay now)</option>' +
      customers.slice().sort((a, b) => a.name.localeCompare(b.name)).map(c => `<option value="${esc(c.id)}">${esc(c.name)}${c.phone ? ' — ' + esc(c.phone) : ''}</option>`).join('');
    sel.value = customers.some(c => c.id === current) ? current : '';
  }
  function addToCart(productId) {
    const p = products.find(x => x.id === productId);
    if (!p || p.stock < 1) return alert('This item is out of stock.');
    const line = cart.find(x => x.id === productId);
    if (line) {
      if (line.qty >= p.stock) return alert('Not enough stock.');
      line.qty += 1;
    } else cart.push({id: productId, qty: 1});
    renderCart();
  }
  function renderCart() {
    // keep the cart consistent with current stock (stock may have changed since items were added)
    cart = cart.filter(line => products.some(p => p.id === line.id && p.stock > 0));
    cart.forEach(line => { const p = products.find(x => x.id === line.id); if (line.qty > p.stock) line.qty = p.stock; });
    const forTab = !!$('billCustomer').value;
    $('walkinWrap').classList.toggle('hidden', forTab);
    $('discountRow').classList.toggle('hidden', forTab);
    $('walkinButtons').classList.toggle('hidden', forTab);
    $('tabButtons').classList.toggle('hidden', !forTab);
    $('billHint').textContent = forTab
      ? 'Items go on this customer\'s tab and stock goes down now. Discount and payment are handled in Customers.'
      : 'Check quantities and total. Saving reduces stock.';
    $('cartItems').innerHTML = cart.map(line => {
      const p = products.find(x => x.id === line.id);
      return `<div class="line"><div class="li"><b>${esc(p.name)}</b><small>${esc(p.model)} &middot; ${money(p.price)} each</small></div>
      <div class="stepper"><button type="button" class="secondary" aria-label="Decrease ${esc(p.name)}" data-step="-1" data-sid="${esc(p.id)}">&minus;</button>
      <input aria-label="Quantity for ${esc(p.name)}" data-qty-id="${esc(p.id)}" type="number" min="1" max="${p.stock}" value="${line.qty}">
      <button type="button" class="secondary" aria-label="Increase ${esc(p.name)}" data-step="1" data-sid="${esc(p.id)}">+</button></div>
      <b class="lt">${money(r2(p.price * line.qty))}</b><button class="x" aria-label="Remove ${esc(p.name)}" data-remove-id="${esc(p.id)}">&times;</button></div>`;
    }).join('') || '<p class="empty">Nothing on the bill yet. Tap an item to add it.</p>';
    const t = totals();
    $('subtotal').textContent = money(t.subtotal);
    $('grandTotal').textContent = money(forTab ? t.subtotal : t.total);
  }
  $('cartItems').addEventListener('change', event => {
    const input = event.target.closest('input[data-qty-id]');
    if (!input) return;
    const line = cart.find(x => x.id === input.dataset.qtyId);
    const p = products.find(x => x.id === input.dataset.qtyId);
    const qty = validNumber(input.value, 1, p?.stock ?? 1, true);
    if (!line || !p || qty === null) { alert('Enter a whole quantity within available stock.'); renderCart(); return; }
    line.qty = qty; renderCart();
  });
  $('cartItems').addEventListener('click', event => {
    const button = event.target.closest('button[data-remove-id]');
    if (button) { cart = cart.filter(x => x.id !== button.dataset.removeId); renderCart(); }
  });
  $('cartItems').addEventListener('click', event => {
    const b = event.target.closest('button[data-step]');
    if (!b) return;
    const line = cart.find(x => x.id === b.dataset.sid), p = products.find(x => x.id === b.dataset.sid);
    if (!line || !p) return;
    const q = line.qty + Number(b.dataset.step);
    if (q < 1) cart = cart.filter(x => x !== line);
    else if (q > p.stock) { say('Only ' + p.stock + ' in stock.'); return; }
    else line.qty = q;
    renderCart();
  });
  function totals() {
    const subtotal = r2(cart.reduce((sum, line) => {
      const p = products.find(x => x.id === line.id); return sum + (p ? p.price * line.qty : 0);
    }, 0));
    const requested = validNumber($('discount').value || 0, 0, 100000000) ?? 0;
    const discount = r2(Math.min(subtotal, requested));
    return {subtotal, discount, total: r2(subtotal - discount)};
  }
  function cartLinesValid() {
    return cart.every(line => {
      const p = products.find(x => x.id === line.id);
      return p && Number.isInteger(line.qty) && line.qty >= 1 && line.qty <= p.stock;
    });
  }
  function receiptHTML(sale, heading) {
    const hasTimes = sale.items.some(i => i.date);
    return `<div class="receipt"><div class="center"><h2>MOBILE PARTS SHOP</h2><div>${esc(heading || 'Sales Receipt')}</div>
      <div>${esc(sale.date)}</div><div>Receipt: ${esc(sale.receipt)}</div></div><hr>
      <div>Customer: <b>${esc(sale.customer || 'Walk-in customer')}</b></div>
      <table><thead><tr>${hasTimes ? '<th>Taken on</th>' : ''}<th>Item</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Total</th></tr></thead><tbody>
      ${sale.items.map(item => `<tr>${hasTimes ? `<td><small>${esc(item.date || '')}</small></td>` : ''}<td>${esc(item.name)}${item.model ? '<br><small>' + esc(item.model) + '</small>' : ''}</td><td class="num">${item.qty}</td><td class="num">${Number(item.price).toFixed(2)}</td><td class="num">${r2(item.qty * item.price).toFixed(2)}</td></tr>`).join('')}
      </tbody></table><hr><div class="receipt-row"><span>Subtotal</span><b>${money(sale.subtotal)}</b></div>
      <div class="receipt-row"><span>Discount</span><b>${money(sale.discount)}</b></div>
      <div class="receipt-row receipt-total"><span>Grand Total</span><b>${money(sale.total)}</b></div><hr>
      <div class="center">${sale.unpaid ? '<span class="tag">UNPAID — AMOUNT DUE</span>' : 'Thank you for shopping!'}</div></div>`;
  }
  function completeSale(print) {
    if (!cart.length) return alert('Add at least one item first.');
    if (!cartLinesValid()) return alert('Please review stock and quantities before saving.');
    const t = totals();
    const stamp = nowStamp();
    const items = cart.map(line => { const p = products.find(x => x.id === line.id); return {id: p.id, name: p.name, model: p.model, qty: line.qty, price: p.price, cost: p.cost}; });
    const sale = {receipt: nextReceipt(), date: stamp.date, timestamp: stamp.timestamp, customer: validText($('customerName').value, 100), items,
      subtotal: t.subtotal, discount: t.discount, total: t.total,
      profit: r2(items.reduce((sum, i) => sum + (i.price - i.cost) * i.qty, 0) - t.discount)};
    products = products.map(p => { const line = cart.find(x => x.id === p.id); return line ? {...p, stock: p.stock - line.qty} : p; });
    sales.unshift(sale);
    cart = []; $('discount').value = '0'; $('customerName').value = '';
    if (!persist()) return;
    if (print) printHTML(receiptHTML(sale)); else say('Sale saved: ' + sale.receipt);
  }
  function clearCart() {
    if (cart.length && !confirm('Clear current bill?')) return;
    cart = []; $('discount').value = '0'; $('customerName').value = ''; renderCart();
  }

  /* ---------- customers / tabs ---------- */
  function tabTotals(c) {
    const subtotal = r2(c.items.reduce((s, i) => s + i.price * i.qty, 0));
    const discount = r2(Math.min(subtotal, Math.max(0, Number(c.discount) || 0)));
    return {subtotal, discount, total: r2(subtotal - discount)};
  }
  function saveCustomer(event) {
    event.preventDefault();
    const name = validText($('cName').value, 100), phone = validText($('cPhone').value, 30);
    if (!name) { $('customerError').textContent = 'Please enter the customer name.'; return; }
    if (customers.some(c => c.name.toLowerCase() === name.toLowerCase() && c.phone === phone)) {
      $('customerError').textContent = 'A customer with this name and phone already exists.'; return;
    }
    const c = {id: makeId(), name, phone, discount: 0, items: []};
    customers.push(c); activeCustomer = c.id;
    $('customerDialog').close();
    persist();
  }
  function addToTab() {
    const c = customers.find(x => x.id === $('billCustomer').value);
    if (!c) return alert('Select a customer first.');
    if (!cart.length) return alert('Add at least one item first.');
    if (!cartLinesValid()) return alert('Please review stock and quantities before saving.');
    const stamp = nowStamp();
    cart.forEach(line => {
      const p = products.find(x => x.id === line.id);
      c.items.push({lid: makeId(), id: p.id, name: p.name, model: p.model, qty: line.qty, price: p.price, cost: p.cost, date: stamp.date, timestamp: stamp.timestamp});
    });
    products = products.map(p => { const line = cart.find(x => x.id === p.id); return line ? {...p, stock: p.stock - line.qty} : p; });
    cart = []; activeCustomer = c.id;
    if (!persist()) return;
    say('Added to ' + c.name + '\'s tab');
  }
  const initial = n => (String(n).trim()[0] || '?').toUpperCase();
  function renderCustomers() {
    const q = ($('customerSearch').value || '').toLowerCase();
    const list = customers.filter(c => (c.name + ' ' + c.phone).toLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name));
    $('customerRows').innerHTML = list.map(c => `<button class="cust-item ${c.id === activeCustomer ? 'active' : ''}" data-cid="${esc(c.id)}">
      <i class="av">${esc(initial(c.name))}</i><span class="cn"><b>${esc(c.name)}</b><small>${esc(c.phone) || (c.items.length ? c.items.length + ' item(s) on tab' : 'No pending items')}</small></span>
      <em>${c.items.length ? money(tabTotals(c).total) : ''}</em></button>`).join('')
      || `<p class="empty">${customers.length ? 'No customer matches your search.' : 'No customers yet. Press "Add customer" to start a tab.'}</p>`;
    renderCustomerDetail();
  }
  $('customerRows').addEventListener('click', event => {
    const b = event.target.closest('button[data-cid]');
    if (b) { activeCustomer = b.dataset.cid; renderCustomers(); }
  });
  function renderCustomerDetail() {
    const c = customers.find(x => x.id === activeCustomer);
    const box = $('customerDetail');
    if (!c) { box.innerHTML = '<p class="empty big-empty">Select a customer to see everything they took.</p>'; return; }
    const t = tabTotals(c);
    const rows = c.items.map(i => `<tr><td class="dim">${esc(i.date)}</td><td><b>${esc(i.name)}</b><small>${esc(i.model)}</small></td><td class="num">${i.qty}</td><td class="num">${money(i.price)}</td><td class="num">${money(r2(i.price * i.qty))}</td>
      <td class="act"><button class="mini danger" data-tab-act="remove" data-lid="${esc(i.lid)}">Remove</button></td></tr>`).join('');
    box.innerHTML = `<div class="cust-head"><i class="av lg">${esc(initial(c.name))}</i><div><h2>${esc(c.name)}</h2><p class="hint">${esc(c.phone) || 'No phone saved'}</p></div>
      <div class="cust-actions"><button data-tab-act="additems">Add items</button><button class="ghost" data-tab-act="deletecustomer">Delete customer</button></div></div>
      <div class="table-wrap inner"><table class="grid"><thead><tr><th>Taken on</th><th>Item</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Total</th><th></th></tr></thead>
      <tbody>${rows || '<tr><td colspan="6" class="empty">Nothing on this tab yet. Press "Add items" to start.</td></tr>'}</tbody></table></div>
      <div class="settle"><div class="settle-row"><span>Subtotal</span><b>${money(t.subtotal)}</b></div>
        <div class="settle-row"><label for="tabDiscount">Discount (Rs.)</label><input id="tabDiscount" type="number" min="0" step="1" value="${c.discount || 0}"></div>
        <div class="settle-row grand"><span>To pay</span><b>${money(t.total)}</b></div></div>
      <div class="actions"><button class="btn-lg" data-tab-act="paidprint" ${c.items.length ? '' : 'disabled'}>Paid &amp; print bill</button>
        <div class="actions-row"><button class="secondary" data-tab-act="paid" ${c.items.length ? '' : 'disabled'}>Paid, don't print</button><button class="secondary" data-tab-act="statement" ${c.items.length ? '' : 'disabled'}>Print list (unpaid)</button></div></div>
      <p class="hint">Paid closes the tab and records one sale for today. To change an item, remove it (stock comes back) and add it again.</p>`;
  }
  $('customerDetail').addEventListener('click', event => {
    const b = event.target.closest('button[data-tab-act]');
    const c = customers.find(x => x.id === activeCustomer);
    if (!b || !c) return;
    const act = b.dataset.tabAct;
    if (act === 'additems') { showPage('billing'); renderBillCustomers(c.id); renderCart(); }
    else if (act === 'remove') removeTabItem(c, b.dataset.lid);
    else if (act === 'statement') printStatement(c);
    else if (act === 'paidprint') settleTab(c, true);
    else if (act === 'paid') settleTab(c, false);
    else if (act === 'deletecustomer') {
      if (c.items.length) return alert('This customer still has items on the tab. Mark it Paid or remove the items first.');
      if (confirm(`Delete customer ${c.name}?`)) { customers = customers.filter(x => x.id !== c.id); activeCustomer = ''; persist(); }
    }
  });
  $('customerDetail').addEventListener('change', event => {
    if (event.target.id !== 'tabDiscount') return;
    const c = customers.find(x => x.id === activeCustomer);
    const d = validNumber(event.target.value, 0, 100000000);
    if (!c) return;
    if (d === null) { alert('Enter a valid discount.'); renderCustomerDetail(); return; }
    c.discount = d; persist();
  });
  function removeTabItem(c, lid) {
    const item = c.items.find(i => i.lid === lid);
    if (!item || !confirm(`Remove ${item.name} (x${item.qty}) from ${c.name}'s tab? Stock will be returned.`)) return;
    c.items = c.items.filter(i => i.lid !== lid);
    products = products.map(p => p.id === item.id ? {...p, stock: p.stock + item.qty} : p);
    persist();
  }
  function tabAsSale(c, receipt) {
    const t = tabTotals(c), stamp = nowStamp();
    const items = c.items.map(i => ({id: i.id, name: i.name, model: i.model, qty: i.qty, price: i.price, cost: i.cost, date: i.date}));
    return {receipt, date: stamp.date, timestamp: stamp.timestamp, customer: c.name, items,
      subtotal: t.subtotal, discount: t.discount, total: t.total,
      profit: r2(items.reduce((s, i) => s + (i.price - i.cost) * i.qty, 0) - t.discount)};
  }
  function printStatement(c) {
    if (!c.items.length) return;
    const s = tabAsSale(c, '—'); s.unpaid = true;
    printHTML(receiptHTML(s, 'Customer Statement'));
  }
  function settleTab(c, print) {
    if (!c.items.length) return alert('Nothing on this tab.');
    const t = tabTotals(c);
    if (!confirm(`${c.name}: received ${money(t.total)}?\nThis closes the tab and saves the sale.`)) return;
    const sale = tabAsSale(c, nextReceipt());
    sales.unshift(sale);
    c.items = []; c.discount = 0;
    if (!persist()) return;
    if (print) printHTML(receiptHTML(sale)); else say('Tab closed. Sale saved: ' + sale.receipt);
  }

  /* ---------- history ---------- */
  function renderHistory() {
    $('historyRows').innerHTML = sales.map((s, idx) => `<tr><td class="dim">${esc(s.date)}</td><td>${esc(s.receipt)}</td>
      <td>${esc(s.customer || 'Walk-in')}</td><td class="num">${s.items.reduce((n, x) => n + x.qty, 0)}</td>
      <td class="num"><b>${money(s.total)}</b></td><td class="num dim">${money(s.profit)}</td>
      <td class="act"><button class="mini secondary" data-reprint="${idx}">Print</button></td></tr>`
    ).join('') || '<tr><td colspan="7" class="empty">No sales yet. Bills you save will appear here.</td></tr>';
  }
  $('historyRows').addEventListener('click', event => {
    const button = event.target.closest('button[data-reprint]');
    const sale = sales[Number(button?.dataset.reprint)];
    if (sale) printHTML(receiptHTML(sale));
  });

  /* ---------- backup / restore ---------- */
  function exportData() {
    const backup = {app: 'Mobile Parts Shop', version: 2, exportedAt: new Date().toISOString(), products, sales, customers};
    const blob = new Blob([JSON.stringify(backup, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = 'mobile-parts-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    try { localStorage.setItem(KEYS.backup, String(Date.now())); } catch (_) {}
    renderBackupNotice();
  }
  function importData(event) {
    const file = event.target.files?.[0]; if (!file) return;
    if (file.size > 10 * 1024 * 1024) { alert('Backup file is too large (10 MB maximum).'); event.target.value = ''; return; }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data || !Array.isArray(data.products) || !Array.isArray(data.sales) || data.products.length > 50000 || data.sales.length > 100000) throw Error();
        if (data.customers !== undefined && (!Array.isArray(data.customers) || data.customers.length > 20000)) throw Error();
        const seen = new Set();
        const cleanProducts = data.products.map(p => {
          if (!p || typeof p !== 'object') throw Error();
          const cost = validNumber(p.cost, 0, 100000000), price = validNumber(p.price, 0, 100000000), stock = validNumber(p.stock, 0, 10000000, true);
          if (!validText(p.name, 100) || cost === null || price === null || stock === null) throw Error();
          let id = validText(p.id, 100) || makeId(); if (seen.has(id)) id = makeId(); seen.add(id);
          const cat = validText(p.category, 50);
          return {id, name: validText(p.name, 100), model: validText(p.model, 100), sku: validText(p.sku, 50), category: CATEGORIES.includes(cat) ? cat : 'Other', cost, price, stock, low: validNumber(p.low ?? 3, 0, 10000000, true) ?? 3};
        });
        const cleanItem = i => {
          if (!i || typeof i !== 'object') throw Error();
          const qty = validNumber(i.qty, 1, 10000000, true), price = validNumber(i.price, 0, 100000000);
          if (qty === null || price === null) throw Error();
          return {id: validText(i.id, 100), name: validText(i.name, 100), model: validText(i.model, 100), qty, price, cost: validNumber(i.cost ?? 0, 0, 100000000) ?? 0, date: validText(i.date, 100)};
        };
        const cleanSales = data.sales.map(s => {
          if (!s || typeof s !== 'object' || !Array.isArray(s.items) || s.items.length > 1000) throw Error();
          const total = validNumber(s.total, 0, 1000000000), subtotal = validNumber(s.subtotal, 0, 1000000000), discount = validNumber(s.discount, 0, 1000000000);
          if (total === null || subtotal === null || discount === null) throw Error();
          return {receipt: validText(s.receipt, 100), date: validText(s.date, 100), timestamp: validNumber(s.timestamp ?? 0, 0, Number.MAX_SAFE_INTEGER) ?? 0, customer: validText(s.customer, 100), items: s.items.map(cleanItem), total, subtotal, discount, profit: validNumber(s.profit ?? 0, -1000000000, 1000000000) ?? 0};
        });
        let cleanCustomers = customers;
        if (data.customers !== undefined) {
          const cseen = new Set();
          cleanCustomers = data.customers.map(c => {
            if (!c || typeof c !== 'object' || !validText(c.name, 100) || (c.items !== undefined && (!Array.isArray(c.items) || c.items.length > 5000))) throw Error();
            let id = validText(c.id, 100) || makeId(); if (cseen.has(id)) id = makeId(); cseen.add(id);
            return {id, name: validText(c.name, 100), phone: validText(c.phone, 30), discount: validNumber(c.discount ?? 0, 0, 100000000) ?? 0,
              items: (c.items || []).map(i => ({...cleanItem(i), lid: makeId(), timestamp: validNumber(i.timestamp ?? 0, 0, Number.MAX_SAFE_INTEGER) ?? 0}))};
          });
        }
        if (!confirm('Restore this backup? Current data will be replaced.')) return;
        products = cleanProducts; sales = cleanSales; customers = cleanCustomers; cart = []; activeCustomer = '';
        if (persist()) alert('Backup restored successfully.');
      } catch (_) { alert('This backup file is invalid or has unsupported data.'); }
      finally { event.target.value = ''; }
    };
    reader.readAsText(file);
  }
  function renderBackupNotice() {
    let last = 0; try { last = Number(localStorage.getItem(KEYS.backup)) || 0; } catch (_) {}
    const days = last ? Math.floor((Date.now() - last) / 86400000) : null;
    const el = $('backupNotice');
    if (days === null) { el.textContent = 'No backup yet. Press Backup in the left menu and keep the file on a USB drive.'; el.classList.add('warn'); }
    else if (days >= 7) { el.textContent = `Last backup was ${days} days ago. Press Backup in the left menu and keep a copy on USB.`; el.classList.add('warn'); }
    else { el.textContent = 'Records stay on this computer. Last backup: ' + (days === 0 ? 'today' : days + ' day(s) ago') + '.'; el.classList.remove('warn'); }
  }

  /* ---------- PIN lock ---------- */
  const cryptoOK = !!(window.crypto && crypto.subtle);
  let failCount = 0, lockedUntil = 0;
  const hex = buf => Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  async function derive(pin, saltHex) {
    const salt = new Uint8Array(saltHex.match(/../g).map(h => parseInt(h, 16)));
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
    return hex(await crypto.subtle.deriveBits({name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256'}, key, 256));
  }
  function getPin() { try { return JSON.parse(localStorage.getItem(KEYS.pin) || 'null'); } catch (_) { return null; } }
  async function checkPin(pin) { const p = getPin(); return !!p && (await derive(pin, p.salt)) === p.hash; }
  function refreshPinButtons() {
    const has = !!getPin();
    $('pinBtn').querySelector('span').textContent = has ? 'Change PIN' : 'PIN lock';
    $('lockNowBtn').classList.toggle('hidden', !has);
    $('pinBtn').classList.toggle('hidden', !cryptoOK);
  }
  function lockNow() { $('lockPin').value = ''; $('lockError').textContent = ''; $('lockScreen').classList.remove('hidden'); $('lockPin').focus(); }
  $('lockNowBtn').addEventListener('click', lockNow);
  $('lockForm').addEventListener('submit', async e => {
    e.preventDefault();
    const wait = Math.ceil((lockedUntil - Date.now()) / 1000);
    if (wait > 0) { $('lockError').textContent = `Too many wrong tries. Wait ${wait}s.`; return; }
    if (await checkPin($('lockPin').value)) { failCount = 0; $('lockScreen').classList.add('hidden'); $('lockPin').value = ''; }
    else { failCount++; lockedUntil = Date.now() + Math.min(60, failCount * 3) * 1000; $('lockError').textContent = 'Wrong PIN.'; $('lockPin').value = ''; }
  });
  $('pinBtn').addEventListener('click', () => {
    const has = !!getPin();
    $('pinForm').reset(); $('pinError').textContent = '';
    $('curPinWrap').classList.toggle('hidden', !has);
    $('removePinBtn').classList.toggle('hidden', !has);
    $('pinDialog').showModal();
  });
  $('cancelPinBtn').addEventListener('click', () => $('pinDialog').close());
  $('removePinBtn').addEventListener('click', async () => {
    if (!(await checkPin($('curPin').value))) { $('pinError').textContent = 'Current PIN is wrong.'; return; }
    try { localStorage.removeItem(KEYS.pin); } catch (_) {}
    $('pinDialog').close(); refreshPinButtons(); alert('PIN removed.');
  });
  $('pinForm').addEventListener('submit', async e => {
    e.preventDefault();
    const has = !!getPin(), n1 = $('newPin').value, n2 = $('newPin2').value;
    if (has && !(await checkPin($('curPin').value))) { $('pinError').textContent = 'Current PIN is wrong.'; return; }
    if (!/^\d{4,8}$/.test(n1)) { $('pinError').textContent = 'PIN must be 4 to 8 digits.'; return; }
    if (n1 !== n2) { $('pinError').textContent = 'The two PINs do not match.'; return; }
    const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
    try { localStorage.setItem(KEYS.pin, JSON.stringify({salt, hash: await derive(n1, salt)})); }
    catch (_) { $('pinError').textContent = 'Could not save the PIN.'; return; }
    $('pinDialog').close(); refreshPinButtons(); alert('PIN saved. Use "Lock" to lock the app any time.');
  });

  /* ---------- dashboard ---------- */
  function renderAll() {
    renderProducts(); renderBillCustomers(); renderBillProducts(); renderCart(); renderHistory(); renderCustomers();
    $('statProducts').textContent = products.length;
    $('statStock').textContent = products.reduce((sum, p) => sum + p.stock, 0);
    const midnight = new Date(); midnight.setHours(0, 0, 0, 0);
    const today = sales.filter(s => s.timestamp >= midnight.getTime());
    $('statSales').textContent = money(r2(today.reduce((sum, s) => sum + s.total, 0)));
    $('statProfit').textContent = money(r2(today.reduce((sum, s) => sum + s.profit, 0)));
    $('statPending').textContent = money(r2(customers.reduce((sum, c) => sum + tabTotals(c).total, 0)));
    const low = products.filter(p => p.stock <= p.low);
    $('lowStock').innerHTML = low.map(p => `<div class="list-line"><span>${esc(p.name)}<small>${esc(p.model)}</small></span><b class="stock-low">${p.stock} left</b></div>`).join('') || '<p class="empty">Nothing is running low.</p>';
    $('recentSales').innerHTML = sales.slice(0, 5).map(s => `<div class="list-line"><span>${esc(s.customer || 'Walk-in')}<small>${esc(s.receipt)}</small></span><b>${money(s.total)}</b></div>`).join('') || '<p class="empty">No sales yet.</p>';
    renderBackupNotice();
    $('quickStart').classList.toggle('hidden', products.length > 0);
  }

  load();
  refreshPinButtons();
  if (getPin()) lockNow();
  renderAll();
})();
